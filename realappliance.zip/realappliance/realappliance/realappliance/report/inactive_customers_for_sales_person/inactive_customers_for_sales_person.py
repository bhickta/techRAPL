# Copyright (c) 2023, Crisco Consulting and contributors
# For license information, please see license.txt

import frappe
from frappe import _
from frappe.utils import cint
from frappe.core.doctype.user_permission.user_permission import get_permitted_documents

def execute(filters=None):
	if not filters:
		filters = {}

	days_since_last_order = filters.get("days_since_last_order")
	doctype = filters.get("doctype")

	if cint(days_since_last_order) <= 0:
		frappe.throw(_("'Days Since Last Order' must be greater than or equal to zero"))

	columns = get_columns()
	customers = get_sales_details(doctype)
	cg = get_permitted_documents("Customer Group")
	result = get_sales_details(doctype)
	data = []
	if cg:
		for row in result:
			if row['customer_group'] in cg:
				data.append(row)

	# for cust in customers:
	# 	if cint(cust[8]) >= cint(days_since_last_order):
	# 		cust.insert(7, get_last_sales_amt(cust[0], doctype))
	# 		data.append(cust)
	return columns, data

def get_sales_details(doctype):
	cond = """sum(so.base_net_total) as 'total_order_considered',
				max(so.posting_date) as 'last_order_date',
				DATEDIFF(CURRENT_DATE, max(so.posting_date)) as 'days_since_last_order' """
	if doctype == "Sales Order":
		cond = """sum(if(so.status = "Stopped",
					so.base_net_total * so.per_delivered/100,
					so.base_net_total)) as 'total_order_considered',
				max(so.transaction_date) as 'last_order_date',
				DATEDIFF(CURRENT_DATE, max(so.transaction_date)) as 'days_since_last_order'"""

	
	return frappe.db.sql(
		"""select
			cust.name,
			cust.customer_name,
			cust.territory,
			cust.customer_group,
			count(distinct(so.name)) as 'num_of_order',
			sum(base_net_total) as 'total_order_value', {0}
		from `tabCustomer` cust, `tab{1}` so
		where cust.name = so.customer and so.docstatus = 1
		group by cust.name
		order by 'days_since_last_order' desc """.format(
			cond, doctype
		),
		as_dict=1,
	)


def get_last_sales_amt(customer, doctype):
	cond = "posting_date"
	if doctype == "Sales Order":
		cond = "transaction_date"
	res = frappe.db.sql(
		"""select base_net_total from `tab{0}`
		where customer = %s and docstatus = 1 order by {1} desc
		limit 1""".format(
			doctype, cond
		),
		customer,
	)

	return res and res[0][0] or 0


def get_columns():
	return [
		{
			"label": _("Customer"),
			"fieldtype": "Link",
			"fieldname": "name",
			"options": "Customer",
			"width": 100,
		},
		{
			"label": _("Customer Name"),
			"fieldtype": "Data",
			"fieldname": "customer_name",
			"width": 100,
		}
  ,
		{
			"label": _("Territory"),
			"fieldtype": "Data",
			"fieldname": "territory",
			"width": 100,
		},
		{
			"label": _("Customer Group"),
			"fieldtype": "Data",
			"fieldname": "customer_group",
			"width": 100,
		},
		{
			"label": _("Number of Order"),
			"fieldtype": "Float",
			"fieldname": "num_of_order",
			"width": 100,
		},
		{
			"label": _("Total Order Value"),
			"fieldtype": "Currency",
			"fieldname": "total_order_value",
			"width": 100,
		},
		{
			"label": _("Total Order Considered"),
			"fieldtype": "Currency",
			"fieldname": "total_orderonsidered",
			"width": 100,
		},
		{
			"label": _("Last Order Date"),
			"fieldtype": "Date",
			"fieldname": "last_order_date",
			"width": 100,
		},
		{
			"label": _("Days Since Last Order"),
			"fieldtype": "Int",
			"fieldname": "days_since_last_order",
			"width": 100,
		}
	]
